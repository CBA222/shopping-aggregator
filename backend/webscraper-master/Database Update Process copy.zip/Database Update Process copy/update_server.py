from http.server import HTTPServer
from admin_panel.request_handler import MainRequestHandler
from sql_database.db_updater import DatabaseUpdater
from sql_database.db_interface import DatabaseInterface

from readers.bestbuy import BestBuyReader
from readers.walmart import WalmartReader

from multiprocessing import Process, Manager

class CustomServer(HTTPServer):
    def serve_forever(self, manager_dict):
        self.RequestHandlerClass.set_manager_dict(manager_dict)
        HTTPServer.serve_forever(self)

class UpdateServer:

    def __init__(self, db_path, server_address):
        self.admin_panel_server = CustomServer(server_address, MainRequestHandler)

        db_interface = DatabaseInterface(db_path)

        self.my_readers = [
            #WalmartReader('key', 3),
            BestBuyReader('Xsk22axb3WQ4bA3KCUbuA3Qf', 5)
        ]

        self.db_updater = DatabaseUpdater(db_interface, self.my_readers)

        #for r in self.my_readers:
        #    r.set_logger(self.db_updater) 
        
    def start(self):
        manager = Manager()
        self.logs_dict = manager.dict()

        for r in self.my_readers:
            self.logs_dict[r.id] = []

        self.db_updater.set_manager_dict(self.logs_dict)

        self.server_process = Process(target=self.admin_panel_server.serve_forever, args=(self.logs_dict,))
        self.update_process = Process(target=self.db_updater.update_all, args=(True,)) 

        self.server_process.start()
        self.update_process.start()
        self.server_process.join()
        self.update_process.join()

    def get_logs(self, id):
        return self.db_updater.logs

if __name__ == '__main__':
    pass