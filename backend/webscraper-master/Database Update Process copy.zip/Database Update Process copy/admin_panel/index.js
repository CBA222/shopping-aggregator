$(document).ready(function() {

    var store_name = '#store-name'
    var base_url = 'http://localhost:8081'
    var logs_box = '#logs-container'

    $('#sidebar > #search-list > #update-list > li').click(function() {

        $(store_name).text($(this).text())

        $.get(base_url + '/data-request:' + $(this).attr('data-id'), function(data, status) {
            $(logs_box).text(data)
        })
        
    })
})