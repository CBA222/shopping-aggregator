from multiprocessing import Pool
import time

def foo(x):
    time.sleep(1)
    #return x*x*x*x*x

my_list = list(range(9))

start = time.time()
with Pool(processes=9) as pool:
    results = pool.map(foo, my_list)

print("elapsed time: {}".format(time.time() - start))