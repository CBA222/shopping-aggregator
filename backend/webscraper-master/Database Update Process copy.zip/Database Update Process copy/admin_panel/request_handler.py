from http.server import BaseHTTPRequestHandler, HTTPServer, SimpleHTTPRequestHandler

class MainRequestHandler(BaseHTTPRequestHandler):

    def set_manager_dict(self, d):
        self.manager_dict = d

    def not_found(self):
        self.send_response(404)
        self.send_header('Content-type','text/html')
        self.end_headers()
        message = "Not found \n Path: {}".format(self.path)
        self.wfile.write(bytes(message, "utf8"))

    def serve_static(self, header_type):
        f = open(self.path[1:])

        self.send_response(200)

        self.send_header('Content-type', header_type)
        self.end_headers()

        self.wfile.write(bytes(f.read(), "utf8"))
        f.close()
        return

    def do_GET(self):
        try:
            if self.path.endswith('.html'):
                self.serve_static('text/html')

            elif self.path.endswith('.css'):
                self.serve_static('text/css')

            elif self.path.endswith('.js'):
                self.serve_static('text/js')

            elif self.path.startswith('/data-request'):
                self.send_response(200)

                self.send_header('Content-type','text/html')
                self.end_headers()

                store_id = self.path[14:]
                data = self.manager_dict(store_id)

                self.wfile.write(bytes(data, "utf8"))

            else:
                self.not_found()


        except IOError:
            self.not_found()
 
def run():
  print('starting server...')
 
  # Server settings
  # Choose port 8080, for port 80, which is normally used for a http server, you need root access
  server_address = ('127.0.0.1', 8081)
  httpd = HTTPServer(server_address, MainRequestHandler)
  print('running server...')
  httpd.serve_forever()


 
 
run()